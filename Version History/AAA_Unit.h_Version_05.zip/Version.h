//Version.h
//Version file for Unit.h

/*********************************************************************************
01 Version 1
02 Version 2 - added doxygen style comments
03 Version 3 - modified this class to become units class.
04 Version 4 - changed variables and added setters and getters
05 Version 5 - 17/03/2018 Wade Davidson, removed inline functions and tested
/*********************************************************************************
